package com.coreJava.employee;
import java.sql.*;
import java.util.connection;


public class Employee {
	public static Connection createConnection() throws ClassNotFoundException, SQLException {
		//register Driver Class
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url=("jdbc:mysql://localhost:3306/Employee");
		String username="root";
		String password="root";
		Connection con=DriverManager.getConnection(url, username, password);
		return con;
	}
	public static void insertRecord() throws ClassNotFoundException, SQLException {
String query="insert into employeejbk (name,EMployeeTown, EmployeeNo)values (\"Santosh Sir\",\"Shirdi\",1234),(\"Kiran Sir\",\"Nagpur\",4567),(\"Mayur sir\",\"Nashik\",34567)";
		
		Connection con=connector.createConnection();
		
		// Establish connection between Java Application And Databases;
		//Create Statement Object
				Statement stm=con.createStatement();
				int num=stm.executeUpdate(query);
				
				System.out.println("Traders data are  Added Sussesfully   ");
				System.out.println(num+" rows are Affected");
				
				con.close();
				stm.close();
				
			}
}
